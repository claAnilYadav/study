

export const FAST_URL = 'https://bkg-rm-api-production-06a3.up.railway.app';//'https://dxmltpiz2ac2inuhad3au4ugqa0pbtqe.lambda-url.us-east-1.on.aws';

export const PG_URL='';
export const BASE_URL = 'https://api.imagexlabs.com';

export const BASE_URL2 = 'https://api.imagexlabs.com';/// Aws ec2 instande prod server

export const environment = {
  production: false,
  IMAGEX_URL: `${FAST_URL}/`,//${API_VERSION}/`,
  API_URL: `${BASE_URL}/`,
  API_URL2: `${BASE_URL2}/`,
  API_key:'4eb5d779-c9f4-4c6f-bedc-3367c4fbb30d',
  master_api_key:'6221c617-1380-4912-88eb-ba737be2b8ce',
  client_id:'875ba47d-ab66-47fa-a6e1-cd5f3e54080b',
  location_id:'ac4c11d6-04ec-4cd1-8fdd-63a5a7bee644',
  SECRET_KEY:'SECRET_KEY'
};
