export interface locationfastx{
    id:string,
    client_id:string,
    name:string,
    description:string,
    api_key:string
}