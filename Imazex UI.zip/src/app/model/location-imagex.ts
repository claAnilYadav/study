export interface locationlist { 
    id: number,
    loc_name: string,
    description: string,
    imagex_location_id: string,
    imagex_client_id: string,
    imagex_api_key: string,
    country_name:string    
}