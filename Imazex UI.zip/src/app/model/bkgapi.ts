export interface bkgapi{
    locationName:string;
    apikey:string;
}