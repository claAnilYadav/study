export interface User {
    name: string;
    lastName: string;
  }
  