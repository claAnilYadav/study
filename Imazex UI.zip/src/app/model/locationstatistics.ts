import { accounting } from "./accounting"

export interface location_statistics{
    date:string,
    name:string
    accounting:accounting[]
}
