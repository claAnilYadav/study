export interface clientfastx{
    id:string,
    name:string,
    description:string
}