export interface locations {
  date: string,
  todate: string,
  name: string,
  country: string,
  accounting: string
}