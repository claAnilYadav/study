export interface accounting {
   accounting_id: number,
    client_id: string,
    location_id: string,
    status: boolean,
    error: any,
    ort_session_time:any,
    matting_time: any,
    main_operation_time: any,
    image_download_time: any,
    created_at:any,
    updated_at:any
  }