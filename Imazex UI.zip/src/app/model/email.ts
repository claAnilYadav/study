export interface Email {
    name: string;
    time: string;
    message: string
  }
  