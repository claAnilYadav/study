import { Component } from '@angular/core';

@Component({
  selector: 'app-create-user-login',
  templateUrl: './create-user-login.component.html',
  styleUrls: ['./create-user-login.component.scss']
})
export class CreateUserLoginComponent {

}
