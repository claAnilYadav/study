import { Component } from '@angular/core';

@Component({
  selector: 'app-create-client-location',
  templateUrl: './create-client-location.component.html',
  styleUrls: ['./create-client-location.component.scss']
})
export class CreateClientLocationComponent {

}
